## Lineage Analysis via Maximum Likelihood)
Github page for [the python code](https://github.com/raphael-group/LAML) of LAML.

### Publication
Will be presented at [RECOMB 2024](https://recomb.org/recomb2024/accepted_papers.html)

### Datasets
Data and some related scripts used in the paper can be found [here]( https://github.com/raphael-group/laml-experiments)

### Contact
Uyen Mai
um6916@princeton.edu

Gillian Chu
gillian.chu@princeton.edu

Ben Raphael
braphael@princeton.edu
