Here we provide tests for the `run_problin.py` script.
